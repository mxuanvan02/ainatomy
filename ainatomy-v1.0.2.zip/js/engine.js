/* AInatomy — TẦNG 2: ENGINE CHẤM TỰ ĐỘNG (oracle) + TẦNG 3: LOG & BẢN ĐỒ NĂNG LỰC
 * Nguyên tắc: đáp án đúng đã biết TRƯỚC từ lúc thiết kế (lỗi do hệ cài sẵn),
 * nên việc chấm là phép so sánh tất định — không cần giáo viên, không cần LLM khi chạy.
 * Toàn bộ dữ liệu lưu trong trình duyệt (localStorage), ẩn danh theo MÃ HỌC SINH,
 * không thu thập họ tên, không gửi gì ra ngoài. Có nút xuất CSV cho giáo viên.
 */
(function(){
  "use strict";

  const META = window.MX_META;
  const KEY = "soiai_dulieu_v1";

  /* ============ LOG (Tầng 3) ============ */
  function doc(){
    try{ return JSON.parse(localStorage.getItem(KEY) || "{}"); }catch(e){ return {}; }
  }
  function ghi(d){
    try{ localStorage.setItem(KEY, JSON.stringify(d)); }
    catch(e){ console.warn("Không lưu được dữ liệu:", e); }
  }

  function vaoLop(maHS, maLop){
    const d = doc();
    const now = Date.now();
    d[maHS] = d[maHS] || { maHS, maLop: maLop || "", tao: now, suKien: [] };
    if(maLop) d[maHS].maLop = maLop;
    ghi(d);
    return d[maHS];
  }

  /* Ghi một sự kiện; loai: "dauTruong" | "lab" | "huanLuyen" */
  function logSuKien(maHS, sk){
    const d = doc();
    if(!d[maHS]) return null;
    sk.t = Date.now();
    d[maHS].suKien.push(sk);
    ghi(d);
    return sk;
  }

  /* ============ CHẤM TẦNG 2 (Đấu trường bắt lỗi AI) ============
   * item: phần tử MX_BANK; traLoi: { verdict:'co_loi'|'dung', loaiLoi?:key }
   * Trả về kết quả chấm tất định.
   */
  function chamDauTruong(item, traLoi){
    const dungVerdict = (traLoi.verdict === item.loai);
    let dungLoai = null;
    if(item.loai === "co_loi" && traLoi.verdict === "co_loi"){
      dungLoai = (traLoi.loaiLoi === item.loaiLoi);
    }
    // Bắt oan: nói "có lỗi" trên câu đúng
    const batOan = (item.loai === "dung" && traLoi.verdict === "co_loi");
    // Bỏ sót: nói "không lỗi" trên câu có lỗi
    const boSot = (item.loai === "co_loi" && traLoi.verdict === "dung");

    const diem = dungVerdict && (item.loai === "dung" || dungLoai === true) ? 1 : 0;

    /* CHỈ SỐ "CHỈ ĐÚNG CHỖ SAI" — thêm 09/10 sau khi một lượt rà soát khoa học đo được
     * rằng thao tác này ĐANG CHẾT. Bằng chứng đo lúc đó: app.js gán `dt.traLoi.claimChon`
     * khi học sinh bấm vào câu nghi sai, nhưng `claimChon` xuất hiện 0 lần trong engine.js
     * và `claimLoi` xuất hiện 0 lần trong CẢ app.js lẫn engine.js — tức giao diện yêu cầu
     * một thao tác, tô sáng nó, rồi không chấm và không ghi nhật ký. Cùng lớp lỗi với
     * trường `phaiLap` từng được ghi mà không có cột CSV nào mang nó.
     *
     * VÌ SAO CHỈ ĐO, KHÔNG TÍNH VÀO `diem`. Đổi công thức điểm sẽ làm MẤT ý của cột cũ và
     * làm gãy khả năng so pre/post với mọi dữ liệu đã thu (nguyên tắc repo đã ghi ở cột
     * `su_kien`: "thêm cột thay vì nhét vào cột sẵn có"). Nên `diem` giữ nguyên, và
     * `claimDung` đi ra như một CHIỀU ĐO RIÊNG: giáo viên thấy được học sinh có thật sự
     * chỉ đúng chỗ sai hay chỉ đoán đúng loại. Việc có đưa nó vào điểm hay không là quyết
     * định sư phạm của tác giả, phải làm có ý thức, không phải tác dụng phụ của một bản vá.
     *
     * `claimChon` là chỉ số 0-based của claim học sinh bấm chọn (app.js đã gán sẵn vào
     * dt.traLoi.claimChon từ trước, nhưng engine KHÔNG đọc — đó chính là Finding 1).
     * Với câu KHÔNG có lỗi thì không có chỗ sai để chỉ, nên `claimDung = null` (không phải
     * 0 — null nghĩa là "không áp dụng", gộp thành 0 sẽ làm tỉ lệ chỉ-đúng-chỗ sai thấp giả). */
    const cc = traLoi.claimChon;
    const claimChon = (cc !== undefined && cc !== null && cc !== -1) ? cc : null;
    const claimDung = item.loai === "co_loi"
      ? (claimChon !== null && claimChon === item.claimLoi ? 1 : 0)
      : null;

    return {
      itemId: item.id,
      mach: item.mach,
      unesco: item.unesco,
      loaiThat: item.loai,
      loaiLoiThat: item.loaiLoi || null,
      traLoiVerdict: traLoi.verdict,
      traLoiLoai: traLoi.loaiLoi || null,
      dungVerdict, dungLoai, diem,
      batOan, boSot,
      claimChon, claimDung,
      giaiThich: item.giaiThich
    };
  }

  /* ============ CHẤM TẦNG 1 (nhiệm vụ lab có đáp án cứng) ============ */
  function chamLab(nhiemVu, chon){
    const dung = (chon === nhiemVu.dapAn);
    return {
      nhiemVuId: nhiemVu.id, mach: nhiemVu.mach, unesco: nhiemVu.unesco,
      chon, dapAn: nhiemVu.dapAn, diem: dung ? 1 : 0, dung,
      giaiThich: nhiemVu.giaiThich
    };
  }

  /* ============ BẢN ĐỒ NĂNG LỰC (Tầng 3) ============ */
  /* Tổng hợp từ log → ma trận 12 khối UNESCO × 4 mạch QĐ 2422 + recall theo loại lỗi */
  function tongHop(maHS){
    const d = doc();
    const hs = maHS ? d[maHS] : null;
    const suKien = hs ? hs.suKien : [];

    const khoi = {};              // unesco -> {dung, tong}
    for(const k in META.unesco) khoi[k] = { dung:0, tong:0 };
    const theoLoai = {};          // loaiLoi -> {phatHien, tongCoLoi, batOan}
    for(const l in META.loaiLoi) theoLoai[l] = { phatHien:0, tongCoLoi:0, batOan:0 };
    let dtTong=0, dtDung=0, labTong=0, labDung=0, hlTong=0;
    let ddTong=0, ddKhop=0, ddBoQua=0;

    for(const sk of suKien){
      /* ---- MỨC 3 (DỰ ĐOÁN TRƯỚC KHI CHẠY) — thêm 06/10 ----
       * LỖI ĐÃ SỬA: 13 ô Mức 3 có ghi sự kiện `loai:"duDoan"` nhưng hàm này KHÔNG có
       * nhánh nào đọc nó (grep -c "duDoan" js/engine.js trả về 0 trước khi sửa). Hệ quả:
       * dự đoán không xuất hiện trong Bản đồ năng lực, không có trong baocao_lop, và CSV
       * của giáo viên không phân biệt được "học sinh dự đoán sai" với "học sinh không
       * thèm dự đoán". Toàn bộ công sức thiết kế 13 ô chết ở khâu báo cáo — đúng chỗ mà
       * giáo viên cần nó nhất để biết lớp hiểu bài tới đâu.
       *
       * Hai dạng sự kiện được đọc:
       *   suKien:"doiChieu" + kq.dung  -> đã dự đoán và đã đối chiếu với kết quả thật
       *   suKien:"boQua"               -> bấm nút chạy mà CHƯA chốt dự đoán (ghi để CSV
       *                                   nói thật; không có sự kiện này thì số liệu trông
       *                                   đẹp hơn thực tế vì chỉ đếm người có tham gia)
       * `kq.dung` do bên ghi chuẩn hoá sẵn (ô số/ô chọn: khop; ô tự luận: chạm >= 60%
       * phương diện), nên ở đây chỉ đọc một dạng, không phải đoán hình dạng dữ liệu. */
      if(sk.loai === "duDoan"){
        if(sk.suKien === "doiChieu" && sk.kq && sk.kq.dung !== undefined){
          ddTong++;
          if(sk.kq.dung) ddKhop++;
        } else if(sk.suKien === "boQua"){
          ddBoQua++;
        }
      }
      if(sk.loai === "dauTruong" && sk.kq){
        const kq = sk.kq;
        dtTong++;
        if(kq.diem) dtDung++;
        if(kq.unesco && khoi[kq.unesco]){ khoi[kq.unesco].tong++; if(kq.diem) khoi[kq.unesco].dung++; }
        if(kq.loaiThat === "co_loi"){
          const t = theoLoai[kq.loaiLoiThat];
          if(t){ t.tongCoLoi++; if(kq.diem) t.phatHien++; }
        }else if(kq.loaiThat === "dung" && kq.batOan){
          // "bắt oan" phân bổ vào loại lỗi HS đã chọn sai
          const t = theoLoai[kq.traLoiLoai];
          if(t) t.batOan++;
        }
      }
      if(sk.loai === "lab" && sk.kq){
        labTong++;
        if(sk.kq.diem) labDung++;
        const u = sk.nhiemVu && sk.nhiemVu.unesco;
        if(u && khoi[u]){ khoi[u].tong++; if(sk.kq.diem) khoi[u].dung++; }
      }
      if(sk.loai === "huanLuyen") hlTong++;
    }

    const tiLeDT = dtTong ? dtDung/dtTong : 0;
    return {
      maHS: maHS || "(tất cả)",
      soSuKien: suKien.length,
      dauTruong: { tong: dtTong, dung: dtDung, tiLe: tiLeDT },
      lab: { tong: labTong, dung: labDung },
      huanLuyenSoLan: hlTong,
      /* Mức 3: ddTong = số lần dự đoán ĐÃ đối chiếu với kết quả thật;
       * ddBoQua = số lần bấm chạy mà không chốt dự đoán. Cả hai đều phải hiện ra:
       * chỉ báo ddTong thì một lớp toàn người bỏ qua trông như "chưa dạy tới",
       * còn báo cả hai thì giáo viên thấy đúng mức độ tham gia. */
      duDoan: { tong: ddTong, khop: ddKhop, boQua: ddBoQua,
                tiLe: ddTong ? ddKhop/ddTong : null },
      recallTheoLoai: Object.keys(theoLoai).map(k => ({
        maLoai: k, ten: META.loaiLoi[k].ten,
        phatHien: theoLoai[k].phatHien, tongCoLoi: theoLoai[k].tongCoLoi,
        batOan: theoLoai[k].batOan,
        recall: theoLoai[k].tongCoLoi ? theoLoai[k].phatHien/theoLoai[k].tongCoLoi : null
      })),
      banDoUNESCO: Object.keys(khoi).map(k => ({
        khoi: k, ten: META.unesco[k].ten, aspect: META.unesco[k].aspect,
        dung: khoi[k].dung, tong: khoi[k].tong,
        tiLe: khoi[k].tong ? khoi[k].dung/khoi[k].tong : null
      })),
      diemManh: null, diemYeu: null, nhanXet: ""
    };
  }

  /* Nhận xét tự động (tất định theo template — không cần LLM khi chạy) */
  function taoNhanXet(th){
    const co = th.recallTheoLoai.filter(r => r.tongCoLoi > 0);
    if(!co.length) return { diemManh:null, diemYeu:null, nhanXet:"Chưa có đủ dữ liệu để nhận xét. Hãy làm phần Đấu trường bắt lỗi AI trước." };
    const sx = co.slice().sort((a,b)=> b.recall - a.recall);
    const manh = sx[0], yeu = sx[sx.length-1];
    const tpl = th.dauTruong.tiLe >= 0.75 ? META.nhanXetMau.gioi
              : th.dauTruong.tiLe >= 0.5  ? META.nhanXetMau.kha
                                          : META.nhanXetMau.canCoGang;
    return {
      diemManh: manh.ten, diemYeu: yeu.ten,
      nhanXet: tpl.replace("{manh}", manh.ten).replace("{yeu}", yeu.ten)
    };
  }

  /* ============ Tổng hợp theo LỚP (aggregate, cho slide/poster) ============ */
  function tongHopLop(maLop){
    const d = doc();
    let gop = null, n = 0;
    for(const k in d){
      if(maLop && d[k].maLop && d[k].maLop !== maLop) continue;
      const th = tongHop(k);
      /* ĐIỀU KIỆN VÀO MẪU — sửa 06/10. Bản cũ là `if(!th.dauTruong.tong) continue;`, tức
       * một HS CHỈ dự đoán Mức 3 mà chưa vào đấu trường thì bị bỏ hẳn khỏi báo cáo lớp,
       * và không được đếm vào soHS. Đó là tái tạo đúng lỗ hổng đang sửa ("Mức 3 vô hình
       * trong báo cáo") ở một tầng khác: dữ liệu có, nhưng bị lọc mất trước khi cộng.
       * Nay nhận HS có bất kỳ dấu vết tham gia nào trong ba loại. */
      const coDauVet = th.dauTruong.tong || th.lab.tong
                    || th.duDoan.tong || th.duDoan.boQua;
      if(!coDauVet) continue;
      n++;
      if(!gop){
        gop = {
          dauTruong:{tong:0,dung:0}, lab:{tong:0,dung:0},
          /* duDoan phải được khởi tạo Ở ĐÂY: bản vá đầu tiên chỉ thêm phép tính
           * `gop.duDoan.tiLe = ...` ở cuối hàm mà quên khai trường này, nên gop.duDoan
           * là undefined và dòng đó ném TypeError. Lỗi không lộ khi đọc lướt vì cú pháp
           * hợp lệ — chỉ chạy thật mới nổ. */
          duDoan:{tong:0,khop:0,boQua:0},
          recall: {}, soHS: 0
        };
        for(const l in META.loaiLoi) gop.recall[l] = {phatHien:0, tongCoLoi:0, batOan:0};
      }
      gop.dauTruong.tong += th.dauTruong.tong;
      gop.dauTruong.dung += th.dauTruong.dung;
      gop.lab.tong += th.lab.tong;
      gop.lab.dung += th.lab.dung;
      gop.duDoan.tong   += th.duDoan.tong;
      gop.duDoan.khop   += th.duDoan.khop;
      gop.duDoan.boQua  += th.duDoan.boQua;
      for(const r of th.recallTheoLoai){
        gop.recall[r.maLoai].phatHien += r.phatHien;
        gop.recall[r.maLoai].tongCoLoi += r.tongCoLoi;
        gop.recall[r.maLoai].batOan += r.batOan;
      }
    }
    if(!gop) return null;
    gop.soHS = n;
    gop.tiLe = gop.dauTruong.tong ? gop.dauTruong.dung/gop.dauTruong.tong : 0;
    /* GỘP MỨC 3 LÊN CẤP LỚP — thêm 06/10. Trước đây hàm này cộng dauTruong, lab và recall
     * nhưng KHÔNG cộng duDoan, nên dù tongHop() của từng HS đã có số liệu Mức 3 thì báo cáo
     * cấp lớp vẫn mù — mà báo cáo lớp mới là thứ giáo viên nhìn để nhận xét cả lớp.
     * tiLe = null (không phải 0) khi chưa ai đối chiếu, để giao diện in "—" thay vì in
     * "0%" và khiến giáo viên tưởng cả lớp dự đoán sai hết. */
    gop.duDoan.tiLe = gop.duDoan.tong ? gop.duDoan.khop/gop.duDoan.tong : null;
    return gop;
  }

  /* ============ BẢNG NHẦM LẪN (confusion matrix) — phục vụ Bài 5 "Dữ liệu lôgic" ============
   * T = "thật sự CÓ lỗi", P = "HS phán quyết CÓ lỗi". Đếm 4 ô từ log, tất định, không cần người chấm.
   *   TP (bắt đúng)      : T ∧ P        → loaiThat='co_loi', verdict='co_loi'
   *   FP (bắt oan)       : ¬T ∧ P       → loaiThat='dung',   verdict='co_loi'  (= cờ batOan)
   *   FN (bỏ sót)        : T ∧ ¬P       → loaiThat='co_loi', verdict='dung'    (= cờ boSot)
   *   TN (xác nhận đúng) : ¬T ∧ ¬P      → loaiThat='dung',   verdict='dung'
   */
  function bangNhamLan(maHS){
    const d = doc();
    const hs = maHS ? d[maHS] : null;
    let TP=0, FP=0, FN=0, TN=0;
    const dem = (sk) => {
      const kq = sk.kq || {};
      if(kq.batOan) FP++;
      else if(kq.boSot) FN++;
      else if(kq.loaiThat === "co_loi" && kq.traLoiVerdict === "co_loi") TP++;
      else if(kq.loaiThat === "dung" && kq.traLoiVerdict === "dung") TN++;
    };
    if(hs) hs.suKien.filter(s => s.loai === "dauTruong").forEach(dem);
    else for(const k in d) d[k].suKien.filter(s => s.loai === "dauTruong").forEach(dem);
    const tong = TP+FP+FN+TN;
    const thatCoLoi = TP+FN, thatDung = FP+TN;
    return {
      TP, FP, FN, TN, tong,
      tiLeDung:   tong ? (TP+TN)/tong : null,
      tiLeBoSot:  thatCoLoi ? FN/thatCoLoi : null,   // false negative rate
      tiLeBatOan: thatDung  ? FP/thatDung  : null    // false positive rate
    };
  }

  /* ============ XUẤT DỮ LIỆU (cho giáo viên làm bằng chứng hồ sơ) ============ */
  function xuatCSV(maLop){
    const d = doc();
    /* CỘT `su_kien` — thêm 06/10. Trước đây ba trạng thái của Mức 3 (chot / doiChieu /
     * boQua) được ghi vào localStorage nhưng CSV KHÔNG có cột nào chứa chúng, nên tệp GV
     * tải về không phân biệt được "dự đoán sai" với "không thèm dự đoán" — đúng lỗ hổng
     * mà phản biện vòng 9 chỉ ra. Thêm cột thay vì nhét vào cột sẵn có, vì nhét thì mất
     * nghĩa của cột cũ.
     *
     * ĐẶT CUỐI BẢNG (không chèn giữa): tools/gop_csv.py đọc CSV bằng dict(zip(head, row))
     * tức THEO TÊN CỘT nên chèn đâu cũng được, nhưng tệp CSV mà GV đã tải về trước đây có
     * header 19 cột; đặt cột mới ở cuối thì tệp cũ và tệp mới cùng được đọc đúng theo tên,
     * không phải lo thứ tự. */
    /* CỘT `claim_dung` — thêm 09/10. Học sinh đã luôn phải bấm vào câu nghi là sai, nhưng
     * trước cột này không tồn tại nên thao tác đó không tới được tay giáo viên: engine.js
     * không đọc claimChon, và CSV không có cột nào mang nó. Nay chamDauTruong() tính
     * `claimDung` (1 = chỉ đúng claim có lỗi, 0 = chỉ sai, "" = câu không có lỗi nên không
     * áp dụng) và nó đi ra thành cột riêng. Đặt CUỐI bảng để tệp CSV cũ (19, 20 rồi 21 cột)
     * vẫn đọc đúng theo tên. Ba nơi phải cùng sửa khi thêm cột: HDR của tools/gop_csv.py,
     * hàm này, và doc_json() trong cùng tệp đó. */
    /* CỘT `yccd` — thêm 11/10 sau khi một thí nghiệm end-to-end chứng minh nó BỊ MẤT.
     *
     * LỖI THẬT, và nó nặng hơn các lỗi mất cột trước vì nó chạm đúng lời hứa của hồ sơ.
     * app.js GHI `yccd: q.yccd` cho hai loại sự kiện (tinhHuong dòng 1149, nhamay-tram0 dòng
     * 1278), logSuKien push nguyên object nên nó CÓ trong localStorage và CÓ trong tệp JSON
     * thô. Nhưng xuatCSV trải phẳng theo 22 cột cố định không có cột nào mang nó, và
     * doc_json() của tools/gop_csv.py cũng không có khoá `yccd` (kèm DictWriter
     * extrasaction="ignore" nên rơi IM LẶNG). Thí nghiệm: nạp JSON có 3 sự kiện mang yccd
     * vào gop_csv.py -> chuỗi mã YCCĐ xuất hiện 0 lần trong cả 3 tệp báo cáo đầu ra.
     *
     * HỆ QUẢ TRÊN HỒ SƠ: hồ sơ khai "22/22 yêu cầu cần đạt có bằng chứng trong mã nguồn",
     * và cổng G16 vẫn ĐẠT 4/4 vì G16 chỉ kiểm BA BẢN KHAI CỘT có khớp nhau không — nó không
     * hề so với danh sách 22 YCCĐ. Nghĩa là một cổng xanh trong khi giáo viên không thể từ
     * nhật ký nói được câu nào về từng yêu cầu cần đạt.
     *
     * `sk.yccd` chứ không phải `kq.yccd`: trường này nằm CÙNG CẤP với kq trong object sự kiện
     * (xem app.js 1145-1150), khác với phai_lap cũng ở cấp sk và claim_dung ở cấp kq. Nhầm
     * cấp thì cột ra rỗng mà không có dấu hiệu.
     * Giá trị có thể là MỘT mã ("10.C4.1") hoặc chuỗi NHIỀU mã ngăn bằng " · " (bảng ánh xạ
     * view ở app.js 1176-1194) — giữ nguyên chuỗi, việc tách để pivot là của báo cáo, không
     * tự tách ở đây vì sẽ phá mô hình một dòng = một sự kiện. */
    const rows = [["ma_hs","ma_lop","loai_su_kien","item_id","mach","unesco","dap_an_dung","loai_loi_that","tra_loi","tra_loi_loai","diem","bat_oan","bo_sot","che_do","phien_tong","phien_dung","phien_bat_oan","phien_bo_sot","thoi_gian_ISO","su_kien","phai_lap","claim_dung","yccd"]];
    for(const k in d){
      if(maLop && d[k].maLop && d[k].maLop !== maLop) continue;
      for(const sk of d[k].suKien){
        const kq = sk.kq || {};
        rows.push([
          k, d[k].maLop || "", sk.loai,
          /* item_id: sự kiện Mức 3 không có kq.itemId (nó không phải nhiệm vụ đấu trường)
           * mà mang mã bài ở sk.baiToan ("BT-10"...). Không fallback thì cả 13 ô đổ về
           * item_id rỗng và tools/gop_csv.py khử trùng lặp theo (ma_hs, item_id, thoi_gian)
           * sẽ coi chúng là bản sao của nhau. */
          kq.itemId || sk.nhiemVuId || sk.baiToan || "",
          kq.mach || (sk.nhiemVu?sk.nhiemVu.mach:"") || "",
          kq.unesco || (sk.nhiemVu?sk.nhiemVu.unesco:"") || "",
          kq.loaiThat || kq.dapAn || "", kq.loaiLoiThat || "",
          /* tra_loi: với Mức 3 câu trả lời của HS là kq.duDoan (con số dự đoán, id phương
           * án, hoặc "6/6" với ô tự luận). Không fallback thì cột trả lời của 13 ô trống. */
          kq.traLoiVerdict || kq.chon || kq.duDoan || "", kq.traLoiLoai || "",
          kq.diem!==undefined?kq.diem:"", kq.batOan?1:0, kq.boSot?1:0,
          sk.cheDo || "", sk.tong!==undefined?sk.tong:"", sk.dung!==undefined?sk.dung:"",
          sk.batOan!==undefined?sk.batOan:"", sk.boSot!==undefined?sk.boSot:"",
          new Date(sk.t).toISOString(),
          sk.suKien || "",
          /* CỘT `phai_lap` — thêm 07/10, và đây là lỗi do CHÍNH đợt vá trước tạo ra.
           * Ở commit trước tôi cho dtBatDau() loại những câu học sinh đã gặp, và khi ngân
           * hàng cạn thì ghi `phaiLap: 1` vào sự kiện phiên, kèm lời hứa NGUYÊN VĂN trong
           * comment: "ghi cờ phaiLap vào nhật ký để tools/gop_csv.py và bất kỳ ai đọc số liệu
           * sau này lọc bỏ được những phiên không còn là phép đo sạch".
           * NHƯNG hàm xuất CSV này không có cột nào mang cờ đó — nên lời hứa không thành sự
           * thật: công cụ gộp không có gì để lọc, và những phiên phải lặp câu vẫn bị trộn vào
           * hiệu pre/post như thường. Writer ghi một trường mà reader không xuất thì trường đó
           * không tồn tại với người dùng cuối — cùng lớp lỗi với việc engine.js từng không đọc
           * sự kiện duDoan, và cùng lớp với G14c từng có một chiều là code chết.
           * Đặt CUỐI bảng để tệp CSV cũ (19 và 20 cột) vẫn đọc đúng theo tên. */
          sk.phaiLap !== undefined ? sk.phaiLap : "",
          /* claimDung là null với câu KHÔNG có lỗi (không có chỗ sai để chỉ). null phải ra
           * Ô RỖNG chứ không ra chữ "null" hay số 0: ra 0 thì tỉ lệ chỉ-đúng-chỗ-sai bị kéo
           * thấp giả, và giáo viên đọc CSV sẽ tưởng học sinh chỉ sai ở cả những câu đúng. */
          (kq.claimDung === null || kq.claimDung === undefined) ? "" : kq.claimDung,
          /* Cột yccd — đọc từ `sk` (cấp sự kiện), KHÔNG từ `kq`. app.js ghi nó cùng cấp với
           * kq: { loai:"tinhHuong", ..., kq:{...}, yccd: q.yccd } (dòng 1145-1150) và
           * { loai:"nhamay", ..., kq:{...}, yccd:q.yccd } (dòng 1274-1279). Đọc nhầm cấp thì
           * cột luôn rỗng mà không có dấu hiệu nào báo — đúng loại lỗi âm thầm mà tệp này
           * đã mắc ba lần (phai_lap, claim_dung, và nay là yccd).
           *
           * FALLBACK `sk.nhiemVu.yccd` — thêm 11/10, LẦN THỨ TƯ của cùng lớp lỗi này, và
           * lần này do MỘT REVIEWER ĐỘC LẬP bắt chứ không phải em tự bắt.
           * js/kienthuc.js ghi yccd LỒNG TRONG `nhiemVu` ở cả hai log site của nó:
           *   dòng 143: nhiemVu:{ id:de.id, mach:"C", unesco:"C2", yccd:"10.C3.2" }
           *   dòng 188: nhiemVu:{ id:q.id, mach:q.mach, unesco:q.unesco, yccd:q.yccd }
           * nên bản chỉ đọc `sk.yccd` bỏ rơi toàn bộ mã của quiz và bài tập prompt — 6 mã
           * (10.A3.1, 10.C2.2, 10.C2.3, 10.C3.1, 10.C3.2, 10.C3.3) không tới được CSV, trong
           * đó có 10.C3.2 là mã DUY NHẤT có thao tác học sinh tự gõ prompt.
           *
           * Vì sao sửa ở ĐÂY thay vì đổi js/kienthuc.js ghi ra cấp ngoài: hai cách đều được,
           * nhưng fallback ở nút đọc thì CHE được cả những trạm sẽ viết sau này theo kiểu lồng,
           * còn đổi chỗ ghi thì mỗi trạm mới lại phải nhớ quy ước. Thứ tự ưu tiên giữ
           * `sk.yccd` trước: nếu một site ghi cả hai cấp thì cấp sự kiện thắng, vì đó là cấp
           * mà tài liệu cột này khai báo. */
          (sk.yccd !== undefined && sk.yccd !== null) ? sk.yccd
            : ((sk.nhiemVu && sk.nhiemVu.yccd !== undefined && sk.nhiemVu.yccd !== null)
               ? sk.nhiemVu.yccd : "")
        ]);
      }
    }
    return rows.map(r => r.map(x => {
      const s = String(x===undefined||x===null?"":x);
      /* CHỐNG FORMULA INJECTION (thêm 08/10, đã chứng minh lỗ thật bằng app sống):
       * `ma_hs`/`ma_lop` là VĂN BẢN TỰ DO học sinh gõ (app.js dangNhap chỉ trim +
       * uppercase, không validate ký tự). Bản cũ chỉ thoát `" , \n` nên HS gõ
       * `=HYPERLINK(...)` hay `+1+1` làm mã của mình thì chuỗi đó đi TRẦN vào ô CSV,
       * và Excel/LibreOffice THỰC THI ô bắt đầu bằng = + - @ khi giáo viên mở tệp.
       * Đo thật bằng browser trước khi vá: payload vào nguyên văn cột 1-2 (HO_FORMULA=true).
       *
       * CÁCH CHẶN: thêm dấu nháy đơn `'` vào ĐẦU ô — cách chuẩn OWASP, Excel/LibreOffice
       * hiển thị `'` là ký tự văn bản và ô thành text chết. CHỈ chặn khi chuỗi KHÔNG PHẢI
       * SỐ HỢP LỆ (isFinite(Number(s))): các cột số của chính app này (diem, tong, dung,
       * bat_oan...) có thể âm hoặc 0/1, và `-1` trong CSV là SỐ chứ không phải formula —
       * prefix vô điều kiện mọi ô bắt đầu bằng `-` sẽ phá dữ liệu thật của giáo viên.
       * Mã HS/lớp hợp lệ (A001, 10A1) không bao giờ bắt đầu bằng = + - @ nên dữ liệu
       * sạch không đổi một byte nào, tools/gop_csv.py đọc theo tên cột không bị ảnh hưởng. */
      const t = (/^[=+\-@\t\r]/.test(s) && !(s !== "" && isFinite(Number(s)))) ? "'" + s : s;
      return /[",\n]/.test(t) ? '"' + t.replace(/"/g,'""') + '"' : t;
    }).join(",")).join("\n");
  }

  function xuatJSON(){ return JSON.stringify(doc(), null, 1); }

  function xoaHet(){ localStorage.removeItem(KEY); }

  /* ================= XÁO VỊ TRÍ PHƯƠNG ÁN (chống mẹo không cần đọc hiểu) =========
   *
   * VÌ SAO CÓ HÀM NÀY (06/10) — số đo trên chính dữ liệu của repo, không phỏng đoán:
   *   js/tinhhuong.js : đáp án là "b" ở 11/12 câu, và "b" đồng thời là phương án DÀI
   *                     NHẤT ở 11/12 câu  -> mẹo "luôn bấm B" đạt 92%.
   *   js/lab.js       : đáp án là "b" ở 4/4 câu, và là phương án dài nhất ở 4/4 câu
   *                     -> mẹo đó đạt 100%.
   *   data/cauhoi.js + cauhoi_moRong.js : claim sai nằm ở vị trí giữa 26/53 item.
   * Một học sinh KHÔNG ĐỌC câu hỏi vẫn đạt 92–100%. Điều đó phá đúng tuyên bố cốt lõi
   * của sản phẩm ("tự chấm khách quan bằng oracle"): con số thu về không còn đo năng
   * lực, nên pre/post và recall đều vô nghĩa nếu học sinh phát hiện ra mẹo.
   *
   * HÀM NÀY SỬA ĐƯỢC GÌ VÀ KHÔNG SỬA ĐƯỢC GÌ — nói rõ để không ai tưởng đã xong:
   *   SỬA ĐƯỢC  mẹo "luôn bấm chữ B". Sau khi xáo, chữ cái hiển thị của đáp án thay đổi
   *             theo câu và theo học sinh, nên không còn vị trí cố định để lợi dụng.
   *   KHÔNG SỬA ĐƯỢC mẹo "chọn phương án dài nhất". Đó là lỗi NỘI DUNG: phương án nhiễu
   *             được viết ngắn hơn đáp án. Không phép xáo trộn nào thay đổi được độ dài
   *             tương đối. Muốn diệt phải VIẾT LẠI phương án nhiễu cho cân độ dài — việc
   *             của tác giả, không phải của mã. Cổng G12 đo cả hai con số và in ra để
   *             khoản nợ này không bị quên.
   *
   * TẤT ĐỊNH theo (mã phiên + id câu): cùng một học sinh mở lại trang vẫn thấy thứ tự cũ
   * (không xáo giữa chừng khi làm lại một câu), nhưng hai học sinh khác nhau thấy thứ tự
   * khác nhau nên không thể chuyền nhau "câu 3 đáp án B". Đặt mã phiên trên window để
   * phép kiểm tự động ghim lại được khi cần tái lập.
   */
  function bamDuong(s){
    let h = 0x811c9dc5;
    for(let i = 0; i < s.length; i++){ h ^= s.charCodeAt(i); h = (h * 0x01000193) >>> 0; }
    return h >>> 0;
  }

  function maPhien(){
    if(window.MX_SEED_PHIEN != null) return String(window.MX_SEED_PHIEN);
    if(!window.__SOIAI_PHIEN){
      window.__SOIAI_PHIEN = String((Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0);
    }
    return window.__SOIAI_PHIEN;
  }

  function xaoLuaChon(ds, mam){
    if(!ds) return [];
    if(ds.length < 2) return ds.slice();
    /* cùng bộ số LCG đã dùng ở js/nhamay_tram01.js — giữ nhất quán trong repo */
    let seed = bamDuong(maPhien() + "|" + String(mam == null ? "" : mam));
    const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
    const a = ds.slice();
    for(let i = a.length - 1; i > 0; i--){
      const j = Math.floor(rnd() * (i + 1));
      const t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  /* Chữ cái hiển thị theo VỊ TRÍ sau khi xáo (0 -> A). Phải lấy theo vị trí chứ không
   * lấy `l.id`: id là nhãn cố định trong dữ liệu, nếu in nó ra thì đáp án vẫn luôn hiện
   * là chữ B dù các phương án đã đổi chỗ — xáo trộn thành vô nghĩa. */
  function chuCai(i){ return String.fromCharCode(65 + i); }

  /* ============ VÌ SAO KHÔNG XÁO THỨ TỰ CÁC CLAIM (quyết định 09/10, có đo) =========
   * Lượt rà soát khoa học 09/10 đo được một khoản nợ THẬT: claim có lỗi nằm ở vị trí GIỮA
   * (index 1) tới 26/53 = 49,1% số câu có lỗi, và riêng trong 56 câu sinh bằng LLM là
   * 20/39 = 51,3% — phân bố đều phải là 33,3%. App vẽ claims thẳng theo thứ tự trong dữ
   * liệu, nên mẹo "nghi câu ở giữa" bắt trúng gần nửa số câu lỗi mà không cần đọc. Đây đúng
   * là LỚP 1 của cổng G12 ("vị trí cố định").
   *
   * NHƯNG XÁO Ở ĐÂY SẼ PHÁ NỘI DUNG, và đó là lý do bản vá đầu tiên đã bị rút lại. Đo thật:
   * 14/78 câu có `giaiThich` tham chiếu VỊ TRÍ của claim ("Câu 3 đưa số liệu '73,6%'…",
   * "Câu 2 viện một 'Công ước quốc tế'…"), và đối chiếu thì 14/14 khớp đúng `claimLoi + 1`
   * (0 câu lệch). Tức LỜI GIẢI đang khoá cứng vào thứ tự gốc. Xáo claims mà không viết lại
   * lời giải thì học sinh đọc "Câu 3" trong khi câu bị tô đỏ nằm ở dòng 1 — tệ hơn cả mẹo vị
   * trí, vì nó dạy sai. Viết lại 14 lời giải thì đụng vào data/cauhoi_moRong.js, đúng tệp
   * đang chờ tác giả duyệt nhãn 56 câu; sửa văn bản giữa lúc duyệt làm kết quả duyệt trỏ vào
   * câu chữ không còn tồn tại.
   *
   * Nên xếp khoản này vào LỚP 2 của G12 — nợ NỘI DUNG, không chữa được bằng mã. Cổng G21
   * trong tools/nghiem_thu.py ĐO nó, in ra tỉ lệ thật và liệt kê từng câu mắc nợ, để nó
   * thành danh sách việc làm có tên thay vì bị quên. Thứ tự làm đúng: (1) tác giả duyệt xong
   * 56 nhãn, (2) viết lại 14 lời giải theo cách không phụ thuộc vị trí ("câu nêu số liệu
   * 73,6%…" thay vì "Câu 3…"), (3) KHI ĐÓ mới xáo claims bằng xaoLuaChon sẵn có.
   * Bước (3) chỉ an toàn sau bước (2). */

  window.MX_ENGINE = {
    doc, ghi, vaoLop, logSuKien,
    chamDauTruong, chamLab,
    tongHop, taoNhanXet, tongHopLop, bangNhamLan,
    xuatCSV, xuatJSON, xoaHet,
    xaoLuaChon, chuCai, maPhien
  };
})();
